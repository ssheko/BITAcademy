using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace ControlTemplates
{
    public partial class GradientButtonVariant : ResourceDictionary
    {
        public GradientButtonVariant()
        {
            InitializeComponent();
        }
    }
}
